var express = require('express');
var app = express();

const {MongoDBConnection} = require('./connection');
const userRouter = require('./routes/user');
const userAuthRouter = require('./routes/user-auth');


// set the view engine to ejs
app.set('view engine', 'ejs');

//connection
MongoDBConnection("mongodb://127.0.0.1:27017/test-user-auth-db2")
.then(()=>console.log("MongoDB connection established..."));
// urlencoded middleware/ plugin
app.use(express.urlencoded({extended: false}));

//routers
app.use("/api/users",userRouter);
app.use("/user/auth", userAuthRouter);

// use res.render to load up an ejs view file

// index page
app.get('/', function(req, res) {
  var mascots = [
    { name: 'Sammy', organization: "DigitalOcean", birth_year: 2012},
    { name: 'Tux', organization: "Linux", birth_year: 1996},
    { name: 'Moby Dock', organization: "Docker", birth_year: 2013}
  ];
  var tagline = "No programming concept is complete without a cute animal mascot.";

  res.render('pages/index', {
    mascots: mascots,
    tagline: tagline
  });
});

// about page
app.get('/about', function(req, res) {
  res.render('pages/about');
});
// about page
app.get('/login', function(req, res) {
    res.render('pages/login');
  });
  // about page
app.get('/signup', function(req, res) {
    res.render('pages/signup');
  });

app.listen(8000);
console.log('Server is listening on port 8080');