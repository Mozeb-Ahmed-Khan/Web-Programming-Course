const mongoose = require('mongoose');

//Schema
const testSchema = new mongoose.Schema({
    user_name:{
        type: String,
        required: true,
    },
    email:{
        type: String,
        required: true,
        unique: true,
    },
} ,{timestamps: true});

// create model
const testUserModel = mongoose.model('users', testSchema);

module.exports = testUserModel;