const express = require('express');

const router = express.Router();
const {handleGetAllUsers, handleGetUserById, handleUpdateUserById, handleDeleteUserById, handleCreateNewUser} = require("../controllers/user");

// API Routes
// get all users and create new user
router.route("/")
.get(handleGetAllUsers)
.post(handleCreateNewUser)

//to handle similar routes 
router.route("/:userId")
.get( handleGetUserById)
.patch(handleUpdateUserById)
.delete(handleDeleteUserById)


module.exports = router;