const express = require('express');

const { handleUserSignUp, handleUserlogin} = require('../controllers/user-auth');

const router = express.Router();

router.post("/", handleUserSignUp);

router.post("/login", handleUserlogin);

router.get("/signup", (req, res)=>{
    return res.render("pages/signup");
});

router.get("/login", (req, res)=>{
    return res.render("pages/login");
});


module.exports = router;