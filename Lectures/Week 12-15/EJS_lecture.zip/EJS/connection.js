const mongoose = require('mongoose');

//connection 
async function MongoDBConnection(url){
    return mongoose.connect(url)
}

module.exports = {
    MongoDBConnection,
}
