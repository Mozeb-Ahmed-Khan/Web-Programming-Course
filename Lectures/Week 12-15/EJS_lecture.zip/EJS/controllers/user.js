const testUserModel = require("../Models/user");

async function handleGetAllUsers(req, res){
    
    const getAllUsers = await testUserModel.find({}); 
    return res.json(getAllUsers);
}

async function handleGetUserById(req, res){
    
    const getUserById = await testUserModel.findById(req.params.userId);
    return res.json(getUserById);
}

async function handleUpdateUserById(req, res){
    
    const updateUserById = await testUserModel.findByIdAndUpdate(req.params.userId, {user_name:"updated_uname"});
    return res.json(updateUserById);
}

async function handleDeleteUserById(req, res){
    const deleteUserById = await testUserModel.findByIdAndDelete(req.params.userId);
    return res.json(deleteUserById);
}

async function handleCreateNewUser(req, res){
   
    const body = req.body;
    try{
        const testResult = await testUserModel.create({
            user_name: body.user_name,
            email: body.email
        });
        console.log("New User:", testResult);
        return res.status(201).json({status: "User created"});
    }
    catch(err){
        return res.status(500).json({status: err});
    }
}

module.exports = {
    handleGetAllUsers,
    handleGetUserById,
    handleUpdateUserById,
    handleDeleteUserById,
    handleCreateNewUser
}