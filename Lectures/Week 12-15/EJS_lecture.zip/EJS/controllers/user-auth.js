const { v4: uuidv4 } = require('uuid');
const UserAuth = require('../models/user-auth');
const {setUser} = require("../util/auth");

async function handleUserSignUp(req, res){
    const {user_name, email, password}= req.body;
    await UserAuth.create({
        user_name, email, password,
    });
    return res.render("pages/login");
}

async function handleUserlogin(req, res){
    const {email, password}= req.body;
    const userLogin = await UserAuth.findOne({email, password});
    console.log(userLogin);
    if(!userLogin){
        return res.render("pages/login", {
            error: "invalid email or password",
        });
    }
    // const sessionId = uuidv4();
    // setUser(sessionId, userLogin);
    // res.cookie("uid", sessionId);
    return res.render("pages/about");
}
module.exports = {
    handleUserSignUp,
    handleUserlogin
}